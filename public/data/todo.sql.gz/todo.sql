-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 02, 2017 at 08:35 PM
-- Server version: 5.7.16-log
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `todo`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `money_spend` decimal(10,0) NOT NULL DEFAULT '0',
  `money_earned` decimal(10,0) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `money_spend`, `money_earned`, `timestamp`) VALUES
(2, '0', '0', '2017-04-03 02:21:10');

-- --------------------------------------------------------

--
-- Table structure for table `assemblyrecords`
--

DROP TABLE IF EXISTS `assemblyrecords`;
CREATE TABLE `assemblyrecords` (
  `assemblyID` int(6) NOT NULL,
  `partTopCACode` varchar(8) NOT NULL,
  `partBodyCACode` varchar(8) NOT NULL,
  `partBtmCACode` varchar(8) NOT NULL,
  `robotID` int(11) NOT NULL,
  `transactionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `buildpartsrecords`
--

DROP TABLE IF EXISTS `buildpartsrecords`;
CREATE TABLE `buildpartsrecords` (
  `id` int(4) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `transactionID` int(11) NOT NULL,
  `partonecacode` varchar(8) NOT NULL,
  `parttwocacode` varchar(8) DEFAULT NULL,
  `partthreecacode` varchar(8) DEFAULT NULL,
  `partfourcacode` varchar(8) DEFAULT NULL,
  `partfivecacode` varchar(8) DEFAULT NULL,
  `partsixcacode` varchar(8) DEFAULT NULL,
  `partsevencacode` varchar(8) DEFAULT NULL,
  `parteightcacode` varchar(8) DEFAULT NULL,
  `partninecacode` varchar(8) DEFAULT NULL,
  `parttencacode` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `parts`
--

DROP TABLE IF EXISTS `parts`;
CREATE TABLE `parts` (
  `id` varchar(6) NOT NULL,
  `model` varchar(2) DEFAULT NULL,
  `pieceId` int(1) DEFAULT NULL,
  `plant` varchar(10) DEFAULT NULL,
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `partName` varchar(5) DEFAULT NULL,
  `line` varchar(60) DEFAULT NULL,
  `pieceName` varchar(60) DEFAULT NULL,
  `pic` varchar(60) DEFAULT NULL,
  `status` int(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `purchasepartsrecords`
--

DROP TABLE IF EXISTS `purchasepartsrecords`;
CREATE TABLE `purchasepartsrecords` (
  `id` int(4) NOT NULL,
  `transactionID` int(11) NOT NULL,
  `cost` int(4) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `partonecacode` varchar(8) NOT NULL,
  `parttwocacode` varchar(8) NOT NULL,
  `partthreecacode` varchar(8) NOT NULL,
  `partfourcacode` varchar(8) NOT NULL,
  `partfivecacode` varchar(8) NOT NULL,
  `partsixcacode` varchar(8) NOT NULL,
  `partsevencacode` varchar(8) NOT NULL,
  `parteightcacode` varchar(8) NOT NULL,
  `partninecacode` varchar(8) NOT NULL,
  `parttencacode` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `returnpartrecords`
--

DROP TABLE IF EXISTS `returnpartrecords`;
CREATE TABLE `returnpartrecords` (
  `id` int(4) NOT NULL,
  `partcacode` varchar(8) NOT NULL,
  `transactionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `robots`
--

DROP TABLE IF EXISTS `robots`;
CREATE TABLE `robots` (
  `id` int(11) NOT NULL,
  `part1CA` varchar(6) NOT NULL,
  `part2CA` varchar(6) NOT NULL,
  `part3CA` varchar(6) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `price` decimal(10,0) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shipmentrecords`
--

DROP TABLE IF EXISTS `shipmentrecords`;
CREATE TABLE `shipmentrecords` (
  `shipmentID` int(6) NOT NULL,
  `partTopCACode` varchar(8) NOT NULL,
  `partBodyCACode` varchar(8) NOT NULL,
  `partBtmCACode` varchar(8) NOT NULL,
  `robotID` varchar(6) NOT NULL,
  `transactionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
CREATE TABLE `token` (
  `id` int(11) NOT NULL,
  `token_session` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`id`, `token_session`) VALUES
(2, '42966c');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `transactionID` int(11) NOT NULL,
  `transacType` varchar(45) NOT NULL,
  `transacMoney` double DEFAULT NULL,
  `transacDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assemblyrecords`
--
ALTER TABLE `assemblyrecords`
  ADD PRIMARY KEY (`assemblyID`),
  ADD KEY `transactionID` (`transactionID`);

--
-- Indexes for table `buildpartsrecords`
--
ALTER TABLE `buildpartsrecords`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactionID` (`transactionID`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `parts`
--
ALTER TABLE `parts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchasepartsrecords`
--
ALTER TABLE `purchasepartsrecords`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactionID` (`transactionID`);

--
-- Indexes for table `returnpartrecords`
--
ALTER TABLE `returnpartrecords`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactionID` (`transactionID`);

--
-- Indexes for table `robots`
--
ALTER TABLE `robots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipmentrecords`
--
ALTER TABLE `shipmentrecords`
  ADD PRIMARY KEY (`shipmentID`),
  ADD KEY `transactionID` (`transactionID`);

--
-- Indexes for table `token`
--
ALTER TABLE `token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transactionID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `assemblyrecords`
--
ALTER TABLE `assemblyrecords`
  MODIFY `assemblyID` int(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `buildpartsrecords`
--
ALTER TABLE `buildpartsrecords`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purchasepartsrecords`
--
ALTER TABLE `purchasepartsrecords`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `returnpartrecords`
--
ALTER TABLE `returnpartrecords`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `robots`
--
ALTER TABLE `robots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `shipmentrecords`
--
ALTER TABLE `shipmentrecords`
  MODIFY `shipmentID` int(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `token`
--
ALTER TABLE `token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transactionID` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `assemblyrecords`
--
ALTER TABLE `assemblyrecords`
  ADD CONSTRAINT `assemblyrecords_ibfk_1` FOREIGN KEY (`transactionID`) REFERENCES `transactions` (`transactionID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `buildpartsrecords`
--
ALTER TABLE `buildpartsrecords`
  ADD CONSTRAINT `buildpartsrecords_ibfk_1` FOREIGN KEY (`transactionID`) REFERENCES `transactions` (`transactionID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchasepartsrecords`
--
ALTER TABLE `purchasepartsrecords`
  ADD CONSTRAINT `purchasepartsrecords_ibfk_1` FOREIGN KEY (`transactionID`) REFERENCES `transactions` (`transactionID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `returnpartrecords`
--
ALTER TABLE `returnpartrecords`
  ADD CONSTRAINT `returnpartrecords_ibfk_1` FOREIGN KEY (`transactionID`) REFERENCES `transactions` (`transactionID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shipmentrecords`
--
ALTER TABLE `shipmentrecords`
  ADD CONSTRAINT `shipmentrecords_ibfk_1` FOREIGN KEY (`transactionID`) REFERENCES `transactions` (`transactionID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
